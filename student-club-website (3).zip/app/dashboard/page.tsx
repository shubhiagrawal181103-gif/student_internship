"use client"

import { useState, useEffect } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarInitials } from "@/components/ui/avatar"
import {
  BookOpen,
  Briefcase,
  Plus,
  Calendar,
  MapPin,
  Users,
  Trophy,
  Settings,
  LogOut,
  Building,
  Clock,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface User {
  email: string
  name: string
  firstName?: string
  lastName?: string
  studentId?: string
  year?: string
  major?: string
}

interface Internship {
  id: string
  company: string
  position: string
  startDate: string
  endDate: string
  status: "completed" | "ongoing" | "upcoming"
  location: string
  description: string
}

export default function DashboardPage() {
  const [user, setUser] = useState<User | null>(null)
  const [internships, setInternships] = useState<Internship[]>([])
  const router = useRouter()

  useEffect(() => {
    // Load user data from localStorage (in real app, fetch from API)
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }

    // Load sample internships (in real app, fetch from API)
    const sampleInternships: Internship[] = [
      {
        id: "1",
        company: "Google",
        position: "Software Engineering Intern",
        startDate: "2024-06-01",
        endDate: "2024-08-30",
        status: "completed",
        location: "Mountain View, CA",
        description: "Worked on Android development team, built new features for Google Play Store.",
      },
      {
        id: "2",
        company: "Microsoft",
        position: "Product Management Intern",
        startDate: "2024-09-01",
        endDate: "2024-12-15",
        status: "ongoing",
        location: "Seattle, WA",
        description: "Supporting Azure product team with market research and feature planning.",
      },
    ]
    setInternships(sampleInternships)
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "ongoing":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "upcoming":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  if (!user) {
    return null
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        {/* Header */}
        <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <Link href="/" className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">TechClub</h1>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Student Dashboard</p>
                </div>
              </Link>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
                <Button variant="outline" size="sm" onClick={handleLogout}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar - Profile */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader className="text-center">
                  <Avatar className="w-20 h-20 mx-auto mb-4">
                    <AvatarFallback>
                      <AvatarInitials name={user.name || user.email} />
                    </AvatarFallback>
                  </Avatar>
                  <CardTitle className="text-xl">{user.name || user.email.split("@")[0]}</CardTitle>
                  <CardDescription>{user.email}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {user.studentId && (
                    <div className="flex items-center gap-2 text-sm">
                      <Badge variant="outline">ID: {user.studentId}</Badge>
                    </div>
                  )}
                  {user.year && (
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="capitalize">{user.year}</span>
                    </div>
                  )}
                  {user.major && (
                    <div className="flex items-center gap-2 text-sm">
                      <BookOpen className="w-4 h-4 text-gray-500" />
                      <span className="capitalize">{user.major.replace("-", " ")}</span>
                    </div>
                  )}
                  <div className="pt-4 border-t">
                    <Link href="/internships/add">
                      <Button className="w-full">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Internship
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg">Quick Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-blue-600" />
                      <span className="text-sm">Total Internships</span>
                    </div>
                    <Badge>{internships.length}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Trophy className="w-4 h-4 text-green-600" />
                      <span className="text-sm">Completed</span>
                    </div>
                    <Badge>{internships.filter((i) => i.status === "completed").length}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <span className="text-sm">Ongoing</span>
                    </div>
                    <Badge>{internships.filter((i) => i.status === "ongoing").length}</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              {/* Welcome Section */}
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                  Welcome back, {user.name || user.email.split("@")[0]}!
                </h1>
                <p className="text-gray-600 dark:text-gray-300">
                  Here's an overview of your internship journey and club activities.
                </p>
              </div>

              {/* Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                        <Briefcase className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">{internships.length}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Total Internships</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                        <Building className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">
                          {new Set(internships.map((i) => i.company)).size}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Companies</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                        <Users className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">TechClub</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Member Since 2024</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Internships */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Your Internships</CardTitle>
                    <CardDescription>Track and manage your internship experiences</CardDescription>
                  </div>
                  <Link href="/internships/add">
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add New
                    </Button>
                  </Link>
                </CardHeader>
                <CardContent>
                  {internships.length === 0 ? (
                    <div className="text-center py-12">
                      <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No internships yet</h3>
                      <p className="text-gray-600 dark:text-gray-400 mb-4">
                        Start tracking your internship experiences to build your professional portfolio.
                      </p>
                      <Link href="/internships/add">
                        <Button>
                          <Plus className="w-4 h-4 mr-2" />
                          Add Your First Internship
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {internships.map((internship) => (
                        <div
                          key={internship.id}
                          className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition-shadow"
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h3 className="font-semibold text-gray-900 dark:text-white">{internship.position}</h3>
                              <p className="text-blue-600 font-medium">{internship.company}</p>
                            </div>
                            <Badge className={getStatusColor(internship.status)}>
                              {internship.status.charAt(0).toUpperCase() + internship.status.slice(1)}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-3">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              <span>
                                {formatDate(internship.startDate)} - {formatDate(internship.endDate)}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              <span>{internship.location}</span>
                            </div>
                          </div>
                          <p className="text-gray-700 dark:text-gray-300 text-sm">{internship.description}</p>
                          <div className="mt-3 flex gap-2">
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}
