"use client"

import type React from "react"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { BookOpen, ArrowLeft, CheckCircle, Upload } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface InternshipFormData {
  company: string
  position: string
  startDate: string
  endDate: string
  location: string
  workType: string
  status: string
  description: string
  skills: string
  projects: string
  supervisor: string
  supervisorEmail: string
  salary: string
  rating: string
  certificate: File | null
}

export default function AddInternshipPage() {
  const [formData, setFormData] = useState<InternshipFormData>({
    company: "",
    position: "",
    startDate: "",
    endDate: "",
    location: "",
    workType: "",
    status: "",
    description: "",
    skills: "",
    projects: "",
    supervisor: "",
    supervisorEmail: "",
    salary: "",
    rating: "",
    certificate: null,
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  const handleInputChange = (field: keyof InternshipFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null
    setFormData((prev) => ({ ...prev, certificate: file }))
  }

  const validateForm = () => {
    const required = ["company", "position", "startDate", "endDate", "location", "workType", "status", "description"]
    for (const field of required) {
      if (!formData[field as keyof InternshipFormData]) {
        return `Please fill in the ${field.replace(/([A-Z])/g, " $1").toLowerCase()} field`
      }
    }

    if (new Date(formData.startDate) >= new Date(formData.endDate)) {
      return "End date must be after start date"
    }

    return null
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    const validationError = validateForm()
    if (validationError) {
      setError(validationError)
      setIsLoading(false)
      return
    }

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // In a real app, you would save to database here
      console.log("Internship data:", formData)

      setSuccess(true)
      setTimeout(() => {
        router.push("/dashboard")
      }, 2000)
    } catch (err) {
      setError("Failed to save internship. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  if (success) {
    return (
      <AuthGuard>
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
          <Card className="w-full max-w-md text-center">
            <CardContent className="pt-6">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Internship Added!</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Your internship experience has been successfully recorded.
              </p>
            </CardContent>
          </Card>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        {/* Header */}
        <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <Link href="/dashboard" className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">TechClub</h1>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Add Internship</p>
                </div>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Add New Internship</h1>
              <p className="text-gray-600 dark:text-gray-300">
                Record your internship experience to build your professional portfolio.
              </p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Internship Details</CardTitle>
                <CardDescription>Fill in the information about your internship experience</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  {/* Basic Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Basic Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="company">Company Name *</Label>
                        <Input
                          id="company"
                          placeholder="e.g., Google, Microsoft, Apple"
                          value={formData.company}
                          onChange={(e) => handleInputChange("company", e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="position">Position/Role *</Label>
                        <Input
                          id="position"
                          placeholder="e.g., Software Engineering Intern"
                          value={formData.position}
                          onChange={(e) => handleInputChange("position", e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="startDate">Start Date *</Label>
                        <Input
                          id="startDate"
                          type="date"
                          value={formData.startDate}
                          onChange={(e) => handleInputChange("startDate", e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="endDate">End Date *</Label>
                        <Input
                          id="endDate"
                          type="date"
                          value={formData.endDate}
                          onChange={(e) => handleInputChange("endDate", e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="status">Status *</Label>
                        <Select onValueChange={(value) => handleInputChange("status", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="ongoing">Ongoing</SelectItem>
                            <SelectItem value="upcoming">Upcoming</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="location">Location *</Label>
                        <Input
                          id="location"
                          placeholder="e.g., San Francisco, CA or Remote"
                          value={formData.location}
                          onChange={(e) => handleInputChange("location", e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="workType">Work Type *</Label>
                        <Select onValueChange={(value) => handleInputChange("workType", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select work type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="onsite">On-site</SelectItem>
                            <SelectItem value="remote">Remote</SelectItem>
                            <SelectItem value="hybrid">Hybrid</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Experience Details */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Experience Details</h3>
                    <div className="space-y-2">
                      <Label htmlFor="description">Job Description *</Label>
                      <Textarea
                        id="description"
                        placeholder="Describe your role, responsibilities, and key achievements..."
                        rows={4}
                        value={formData.description}
                        onChange={(e) => handleInputChange("description", e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="skills">Skills Gained</Label>
                      <Textarea
                        id="skills"
                        placeholder="List the technical and soft skills you developed (e.g., React, Python, Leadership, Communication)..."
                        rows={3}
                        value={formData.skills}
                        onChange={(e) => handleInputChange("skills", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="projects">Key Projects</Label>
                      <Textarea
                        id="projects"
                        placeholder="Describe the main projects you worked on and their impact..."
                        rows={3}
                        value={formData.projects}
                        onChange={(e) => handleInputChange("projects", e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Additional Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Additional Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="supervisor">Supervisor Name</Label>
                        <Input
                          id="supervisor"
                          placeholder="e.g., John Smith"
                          value={formData.supervisor}
                          onChange={(e) => handleInputChange("supervisor", e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="supervisorEmail">Supervisor Email</Label>
                        <Input
                          id="supervisorEmail"
                          type="email"
                          placeholder="supervisor@company.com"
                          value={formData.supervisorEmail}
                          onChange={(e) => handleInputChange("supervisorEmail", e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="salary">Salary/Stipend (Optional)</Label>
                        <Input
                          id="salary"
                          placeholder="e.g., $5000/month or Unpaid"
                          value={formData.salary}
                          onChange={(e) => handleInputChange("salary", e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="rating">Overall Rating</Label>
                        <Select onValueChange={(value) => handleInputChange("rating", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Rate your experience" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="5">⭐⭐⭐⭐⭐ Excellent</SelectItem>
                            <SelectItem value="4">⭐⭐⭐⭐ Very Good</SelectItem>
                            <SelectItem value="3">⭐⭐⭐ Good</SelectItem>
                            <SelectItem value="2">⭐⭐ Fair</SelectItem>
                            <SelectItem value="1">⭐ Poor</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="certificate">Certificate/Completion Letter</Label>
                      <div className="flex items-center gap-4">
                        <Input
                          id="certificate"
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={handleFileChange}
                          className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                        />
                        <Upload className="w-5 h-5 text-gray-400" />
                      </div>
                      <p className="text-sm text-gray-500">
                        Upload completion certificate or offer letter (PDF, JPG, PNG)
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4 pt-6">
                    <Button type="submit" className="flex-1" disabled={isLoading}>
                      {isLoading ? "Saving..." : "Save Internship"}
                    </Button>
                    <Link href="/dashboard">
                      <Button type="button" variant="outline" className="px-8 bg-transparent">
                        Cancel
                      </Button>
                    </Link>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}
